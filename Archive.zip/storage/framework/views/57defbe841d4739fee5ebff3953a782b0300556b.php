<div id="outer">
  <div id="inner" class="card">

    <table class="card-body p-0 m-0 table table-sm w-100 table-responsive-md table-bordered table-hover">
                            <thead class="text-center thead-dark">
                                <tr>
                                    <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', ' ID', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                    <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('first_name', 'First Name', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                    <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('last_name', 'Last Name', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                    <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('company.company_name', 'Company Name', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                    <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email', 'Email', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                    <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('phone', 'Phone', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                    <th class="align-middle main-column" style="width:100px; visibility: hidden;">Empty</th>
                                    <th id="links-header" class="align-middle links-column links-header">Links</th>
                                </tr>
                            </thead>

                            <tbody class="list">
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php $employeeCompany = $employee->company->company_name;?>
                              <tr class="employee-tr">
                                    <td class="align-middle main-column"> <?php echo e($employee->id); ?> </td>
                                    <td class="align-middle main-column"> <?php echo e($employee->first_name); ?> </td>
                                    <td class="align-middle main-column"> <?php echo e($employee->last_name); ?> </td>
                                    <td class="align-middle main-column"> <?php echo e($employeeCompany); ?> </td>
                                    <td class="align-middle main-column"> <?php echo e($employee->email); ?> </td>
                                    <td class="align-middle main-column"> <?php echo e($employee->phone); ?> </td>
                                    <td id="empty" class="align-middle empty">Empty</td>
                                    <td id="table-links" class="align-middle employee-links links-column links-data p-0 m-0">
                                      <div  class="links-div">
                                           <a class="btn btn-success table-link" <?php echo e(Popper::arrow()->pop('View')); ?> href="<?php echo e(route('employees.show', $employee->id)); ?>"><i class="far fa-eye tooltiptext"></i></a>
                                           <a class="btn btn-success table-link"  <?php echo e(Popper::arrow()->pop('Edit')); ?> href="<?php echo e(route('employees.edit', $employee->id)); ?>"><i class="far fa-edit tooltiptext"></i></a>
                                       </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

          </table>

        </div>
      </div>
<?php echo $employees->appends(request()->except('page'))->render(); ?>

<?php /**PATH /Users/joewood/Documents/company-manager/resources/views/includes/employee-table.blade.php ENDPATH**/ ?>