<nav id="side-nav" class="pushy pushy-left">
  <div id="sidenav-inner" class="pushy-content">
    <div id="menu-top">
      <h1>Tables</h1>
    </div>
    <div id="sidenav-content">

      <ul id="sidenav-links">
        <li><a href="/companies" class="pushy-link"><i class="fas fa-building"></i>Companys</a></li>
        <li><a href="/employees" class="pushy-link"><i class="fas fa-users"></i>Employees</a></li>
      </ul>
    </div>
  </div>
  </nav>
<?php /**PATH /Users/joewood/Documents/company-manager/resources/views/includes/sidenav.blade.php ENDPATH**/ ?>