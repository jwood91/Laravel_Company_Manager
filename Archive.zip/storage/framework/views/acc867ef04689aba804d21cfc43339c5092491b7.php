<div id="outer" class="">
  <div id="inner" class= "card">

      <table class="card-body p-0 m-0 table table-sm w-100 table-responsive-md table-bordered table-hover">
                              <thead class="text-center thead-dark">
                                  <tr>
                                      <th class="align-middle main-column "><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', 'ID', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                      <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('company_name', 'Company Name', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                      <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email', 'Email', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                      <th class="align-middle main-column"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('website', 'Website', ['parameter' => 'smile'], ['class' => 'sort-link']));?></th>
                                      <th id="logo" class="align-middle main-column">Logo</th>
                                      <th class="align-middle empty" style="width:100px; visibility: hidden;">Empty</th>
                                      <th id="links-header" class="align-middle links-header links-column">Links</th>

                                  </tr>
                              </thead>

                              <tbody class=" text-center">
                                  <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="company-tr">
                                      <td class="align-middle main-column"><?php echo e($company->id); ?> </td>
                                      <td class="align-middle main-column"> <?php echo e($company->company_name); ?> </td>
                                      <td class="align-middle main-column"> <?php echo e($company->email); ?></td>
                                      <td class="align-middle main-column" style="max-width:250px"> <?php echo e($company->website); ?></td>
                                      <td class="align-middle main-column"> <img src="<?php echo e(url('/storage/images/'.basename($company->logo))); ?>" style="width: 80px; height: 70px;"/></td>
                                      <td id="empty" class="align-middle empty" style="visibility: hidden;">Empty</td>
                                       <td id="table-links" class="align-middle company-links  links-data links-column p-0 m-0">
                                         <div class="links-div">
                                              <a class="btn btn-success table-link" <?php echo e(Popper::arrow()->pop('View')); ?> href="<?php echo e(route('companies.show', $company->id)); ?>"><i class="far fa-eye tooltiptext"></i></a>
                                              <a class="btn btn-success table-link"  <?php echo e(Popper::arrow()->pop('Edit')); ?> href="<?php echo e(route('companies.edit', $company->id)); ?>"><i class="far fa-edit tooltiptext"></i></a>
                                          </div>
                                       </td>

                                  </tr>

                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
          </table>
        </div>
      </div>
          <?php echo $companies->appends(request()->except('page'))->render(); ?>

<?php /**PATH /Users/joewood/Documents/company-manager/resources/views/includes/company-table.blade.php ENDPATH**/ ?>