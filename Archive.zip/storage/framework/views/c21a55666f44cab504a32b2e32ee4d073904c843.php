<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('content', null, []); ?> 

      <h1>COMPANY INFORMATION</h1>

      <div id="company-container" class="show-container">
        <div id="show-buttons">
            <div class="pull-right">
                <a class="btn btn-success show-button" href="<?php echo e(route('companies.index', $company->id)); ?>">Back</a>
            </div>
            <div class="pull-right">
                <a class="btn btn-success show-button" href="<?php echo e(route('companies.edit', $company->id)); ?>">Edit</a>
            </div>
          </div>
        <div id="company-inner" class="show-inner">

            <div id="company-id" class="company-details information-input">
                <label for="id" class="company-label">Company ID:</label>
                <p name="id" class="text-input"><?php echo e($company->id); ?></p>
            </div>
            <div id="company-name" class="company-details information-input">
              <label for="name" class="company-label">Company Name:</label>
              <p name="name" class="text-input"><?php echo e($company->company_name); ?></p>
            </div>
            <div id="company-email" class="company-details information-input">
              <label for="email" class="company-label">Email:</label>
              <a href="mailto:<?php echo e($company->email); ?>" name="email" class="text-input"><?php echo e($company->email); ?></a>
            </div>
            <div id="company-website" class="company-details information-input">
              <label for="website" class="company-label">Website:</label>
              <a  name="website" class="text-input" href="<?php echo e($company->website); ?>" target="_blank">View company website</a>
            </div>
            <div id="current-company-logo" class="logo-input company-details">
              <label for="logo" class="company-label">Logo:</label>
              <img name="logo" class="company-details" src="<?php echo e(url('/storage/images/'.basename($company->logo))); ?>" style="height:100px; width: 100px;">
            </div>
        </div>
      </div>

    <?php echo $__env->make('includes.employee-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




   <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/joewood/Documents/company-manager/resources/views/companies/show.blade.php ENDPATH**/ ?>