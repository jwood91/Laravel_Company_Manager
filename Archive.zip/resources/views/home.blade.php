<x-layout>
  <x-slot name="content">

    <div id="home-container">
      <h1> Welcome to the company manager</h1>
      <div id="access-site">
          <div class="home-button">
                  <a type="link" href="companies" class="btn btn-success">Go to Companies</a>
          </div>
          <div class="home-button">
                  <a type="link" href="employees" class="btn btn-success">Go to Employees</a>
          </div>
      </div>
    </div>
  </x-slot>
</x-layout>
